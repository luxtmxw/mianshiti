//
//  MyAnnotation.swift
//  WeatherForecast
//
//  Created by luxtmxw on 16/9/28.
//  Copyright © 2016年 luxtmxw. All rights reserved.
//

import UIKit
import MapKit

class MyAnnotation: NSObject {

}

