//
//  ViewController.swift
//  WeatherForecast
//
//  Created by luxtmxw on 16/9/27.
//  Copyright © 2016年 luxtmxw. All rights reserved.
//

import UIKit
import CoreLocation
import MBProgressHUD
import MapKit

class ViewController: UIViewController {

    @IBOutlet weak var containView: UIView!
    @IBOutlet weak var cityLbl: UILabel!
    @IBOutlet weak var tempLbl: UILabel!
    @IBOutlet weak var humidityLbl: UILabel!
    @IBOutlet weak var AQILbl: UILabel!
    @IBOutlet weak var qualityLbl: UILabel!
    @IBOutlet weak var timeLbl: UILabel!
    
    @IBOutlet weak var mapView: MKMapView!
    
    var locationManager: CLLocationManager!
    var geocoder: CLGeocoder!
    var cityNow: AirQuality!
    var city: String!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setRightBarBtn()
        initCLLoactionMange()
        setNavigationBar()
        NSNotificationCenter.defaultCenter().addObserver(self, selector: "notificationAction:", name: "getCity", object: nil)
        // Do any additional setup after loading the view, typically from a nib.
    }

    func notificationAction(notification: NSNotification) {
        getAirQuality(self.city)
        NSNotificationCenter.defaultCenter().removeObserver(self, name: "getCity", object: nil)
    }
    
    func setRightBarBtn() {
        let right = UIBarButtonItem(title: "系统设置", style: .Done, target: self, action: "systemSettingAction")
        self.navigationItem.rightBarButtonItem = right
    }
    
    func systemSettingAction() {
        let systemVC = Main.instantiateViewControllerWithIdentifier("system") as! SystemSettingViewController
        navigationController?.pushViewController(systemVC, animated: true)
    }
    
    func configure(city: String, quality: AirQuality, weather: Weather) {
        self.containView.hidden = false
        self.cityLbl.text = city
        self.tempLbl.text = "温度:  \(weather.temp)"
        self.humidityLbl.text = "湿度:  \(weather.humidity)"
        self.AQILbl.text = "AQI:  \(quality.AQI)"
        self.qualityLbl.text = "空气质量: \(quality.quality)"
        self.timeLbl.text = weather.time
    }
    
    func setMap(coordinate: CLLocationCoordinate2D) {
        mapView.delegate = self
        mapView.showsUserLocation = true
        let theCoordinate = coordinate
        let theSpan = MKCoordinateSpan(latitudeDelta: 2.0, longitudeDelta: 2.0)
        let region = MKCoordinateRegion(center: theCoordinate, span: theSpan)
        mapView.setRegion(region, animated: true)
        
        let anno1 = MKPointAnnotation()
        anno1.coordinate = CLLocationCoordinate2D(latitude: 31.22, longitude: 121.48)
        anno1.title = "上海"
        anno1.subtitle = "上海"
//        mapView.addAnnotation(anno1)
    
        
        let anno2 = MKPointAnnotation()
        anno2.coordinate = CLLocationCoordinate2D(latitude: 31.3, longitude: 120.6)
        anno2.title = "苏州"
        anno2.subtitle = "苏州"
//        mapView.addAnnotation(anno2)
        
        let anno3 = MKPointAnnotation()
        anno3.coordinate = CLLocationCoordinate2D(latitude: 30.3, longitude: 120.2)
        anno3.title = "杭州"
        anno3.subtitle = "杭州"
        mapView.addAnnotations([anno1, anno2, anno3])
        
    }
    
    func initCLLoactionMange() {
        locationManager = CLLocationManager()
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        
        if locationManager.respondsToSelector("requestWhenInUseAuthorization") {
            locationManager.requestAlwaysAuthorization()
//            locationManager.requestWhenInUseAuthorization()
        }
        
        locationManager.startUpdatingLocation()
    }
    
    func setNavigationBar() {
        title = "城市空气质量"
        self.navigationController?.navigationBar.titleTextAttributes = [NSForegroundColorAttributeName: UIColor.whiteColor()]
        self.navigationController?.navigationBar.tintColor = UIColor.whiteColor()
        self.navigationController?.navigationBar.lt_setBackgroundColor(UIColor.colorWithHexCode("333"))
        self.navigationController?.navigationBar.shadowImage = UIImage()
        self.navigationItem.backBarButtonItem = UIBarButtonItem(title: " ", style: .Done, target: nil, action: nil)
        UIApplication.sharedApplication().setStatusBarStyle(UIStatusBarStyle.LightContent, animated: true)
    }
    
    func getAirQuality(city: String) {
        let mb = MBProgressHUD.showHUDAddedTo(self.view, animated: true)
        mb.label.text = "正在加载"
        WeatherServerInstance.getAirQuality(city: city.changeStringToUTF8(), succeed: { (cityNow, airQualitys) -> Void in
            self.cityNow = cityNow
            self.getWeather(city)
            }) { () -> Void in
                MBProgressHUD.hideHUDForView(self.view, animated: true)
                print("失败")
        }
    }
    
    func getWeather(city: String) {
        MBProgressHUD.hideHUDForView(self.view, animated: true)
        WeatherServerInstance.getWeatherForecast(city: city.changeStringToUTF8(), succeed: { (weather) -> Void in
            self.configure(city, quality: self.cityNow, weather: weather)
            }) { () -> Void in
//                MBProgressHUD.hideHUDForView(self.view, animated: true)
                print("失败")
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

extension ViewController: CLLocationManagerDelegate {
    func locationManager(manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        let location = locations.last
        setMap((location?.coordinate)!)
        geocoder = CLGeocoder()
        geocoder.reverseGeocodeLocation(location!) { (placemarks, error) -> Void in
            if error != nil || placemarks!.count == 0 {
                self.getAirQuality("上海")
            }else {
                let firstPlacemark = placemarks?.first
                var city: String! = firstPlacemark?.locality
                city = (city as NSString).substringToIndex(city.characters.count - 1)
                self.city = city
                NSNotificationCenter.defaultCenter().postNotificationName("getCity", object: nil)
            }
        }
        
        manager.stopUpdatingLocation()
    }
    
    func locationManager(manager: CLLocationManager, didFailWithError error: NSError) {
//        if error.code == kCLErrorDomain {
//            
//        }
    }
}

extension ViewController: MKMapViewDelegate {
    
    
    func mapView(mapView: MKMapView, viewForAnnotation annotation: MKAnnotation) -> MKAnnotationView? {
        
        var pinView: MKPinAnnotationView?
        let defaultID = "目的地"
        pinView = mapView.dequeueReusableAnnotationViewWithIdentifier(defaultID)as? MKPinAnnotationView
        if pinView == nil {
            pinView = MKPinAnnotationView(annotation: annotation, reuseIdentifier: defaultID)
            pinView?.rightCalloutAccessoryView = UIButton(type: .DetailDisclosure)
            pinView?.pinColor = MKPinAnnotationColor.Purple
            pinView?.canShowCallout = true
            pinView?.animatesDrop = true
            pinView?.draggable = true
            pinView?.selected = true
        }else {
            pinView?.annotation = annotation
        }
        
        return pinView
    }
    
    func mapView(mapView: MKMapView, didSelectAnnotationView view: MKAnnotationView) {
        let geo = CLGeocoder()
        let location = CLLocation(latitude: (view.annotation?.coordinate.latitude)!, longitude: (view.annotation?.coordinate.longitude)!)
        geo.reverseGeocodeLocation(location) { (placemarks, error) -> Void in
            if error != nil || placemarks!.count == 0 {
            }else {
                let firstPlacemark = placemarks?.first
                var city: String! = firstPlacemark?.locality
                city = (city as NSString).substringToIndex(city.characters.count - 1)
                let detailVC = DetailViewController()
                detailVC.city = city
                self.navigationController?.pushViewController(detailVC, animated: true)
            }

        }
    }
}
