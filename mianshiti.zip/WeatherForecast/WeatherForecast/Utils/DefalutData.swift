import UIKit

let weatherAppKey = "948b95875b2d57b0bc77c3586a2dd561"
let airAppKey = "e24a7dee82f2cb6615813b28c0c6949f"
let weatherHeadUrl = "http://v.juhe.cn/weather/index"
let airHeadUrl = "http://web.juhe.cn:8080/environment/air/cityair"

//屏幕宽高
let kScreenWidth = UIScreen.mainScreen().bounds.width
let kScreenHeight = UIScreen.mainScreen().bounds.height

let airQuality_coredata = "QualityCoreData"

let Main = UIStoryboard(name: "Main", bundle: nil)