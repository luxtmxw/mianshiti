//
//  DelayDismiss.swift
//  APITest
//
//  Created by 王渊博 on 16/1/26.
//  Copyright © 2016年 luxtmxw. All rights reserved.
//

import UIKit

class DelayDismiss: NSObject {
    
    class var sharedInstance: DelayDismiss {
        struct Singleton {
            static let instance = DelayDismiss()
        }
        return Singleton.instance
    }
    
    func delayDismiss() {
        // 过5秒秒自动消失
        let delayInSeconds2 = 5.0
        let popTime2 = dispatch_time(DISPATCH_TIME_NOW,
            Int64(delayInSeconds2 * Double(NSEC_PER_SEC))) // 1
        dispatch_after(popTime2, dispatch_get_main_queue()) { // 2
//            RefreshSai.sharedInstance.dismissWithAnimation()
        }

    }
}
