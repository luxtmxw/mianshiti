//
//  AirQuality.swift
//  WeatherForecast
//
//  Created by luxtmxw on 16/9/27.
//  Copyright © 2016年 luxtmxw. All rights reserved.
//

import UIKit
import SwiftyJSON

class AirQuality: NSObject {
    
    var AQI: String!
    var city: String!
    var date: String!
    var quality: String!
    
    convenience init(json: JSON) {
        self.init()
        self.AQI = json["AQI"].stringValue
        self.city = json["city"].stringValue
        self.date = json["date"].stringValue
        self.quality = json["quality"].stringValue
    }
}
