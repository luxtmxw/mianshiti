//
//  Weather.swift
//  WeatherForecast
//
//  Created by luxtmxw on 16/9/27.
//  Copyright © 2016年 luxtmxw. All rights reserved.
//

import UIKit
import SwiftyJSON

class Weather: NSObject {

    var temp: String!
    var humidity: String!
    var time: String!
    
    convenience init(json: JSON) {
        self.init()
        self.temp = json["temp"].stringValue
        self.humidity = json["humidity"].stringValue
        self.time = json["time"].stringValue
    }
}
