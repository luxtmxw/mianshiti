//
//  WeatherForecastServer.swift
//  WeatherForecast
//
//  Created by luxtmxw on 16/9/27.
//  Copyright © 2016年 luxtmxw. All rights reserved.
//

import UIKit
import SwiftyJSON
import Alamofire

let WeatherServerInstance = WeatherForecastServer.sharedInstance

class WeatherForecastServer: NSObject {
    
    static let sharedInstance = WeatherForecastServer()
    
    //天气预报
    func getWeatherForecast(city city: String, succeed: (weather: Weather) -> Void, fail: () -> Void) {
        let requestURL = weatherHeadUrl + "?cityname=\(city)&key=\(weatherAppKey)"
        AlamofireInstance.requestNoHeader(.GET, requestURL, encoding: .JSON) { (response, data) -> Void in
            guard data.value != nil else {
                fail()
                return
            }
            if response?.statusCode == 200 {
                let json = JSON(data.value!)
                let weather = Weather(json: json["result"]["sk"])
                succeed(weather: weather)
            }else {
                fail()
            }
        }
    }
    
    //空气质量
    func getAirQuality(city city: String, succeed: (cityNow: AirQuality, airQualitys: [AirQuality]) -> Void, fail: () -> Void) {
        let requestURL = airHeadUrl + "?city=\(city)&key=\(airAppKey)"
        print(requestURL)
        AlamofireInstance.requestNoHeader(.GET, requestURL, encoding: .JSON) { (response, data) -> Void in
            guard data.value != nil else {
                fail()
                return
            }
            if response?.statusCode == 200 {
                let json = JSON(data.value!)
                dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), { () -> Void in
                    let cityNowJson = json["result"][0]["citynow"]
                    let cityNow = AirQuality(json: cityNowJson)
                    
                    let cityHistoryJson = json["result"][0]["lastTwoWeeks"]
                    var cityHistorys = [AirQuality]()
                    for i in 0..<cityHistoryJson.count {
                        cityHistorys.append(AirQuality(json: cityHistoryJson["\(cityHistoryJson.count - 1 - i)"]))
                    }
                    dispatch_async(dispatch_get_main_queue(), { () -> Void in
                        succeed(cityNow: cityNow, airQualitys: cityHistorys)
                    })
                })
            }else {
                fail()
            }
        }
    }
    
}
