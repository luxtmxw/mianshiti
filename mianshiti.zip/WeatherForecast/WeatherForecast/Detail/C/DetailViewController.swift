//
//  DetailViewController.swift
//  WeatherForecast
//
//  Created by luxtmxw on 16/9/27.
//  Copyright © 2016年 luxtmxw. All rights reserved.
//

import UIKit
import MBProgressHUD

class DetailViewController: UIViewController {

    var tableView: UITableView!
    var cityHistorys = [AirQuality]()
    var weather: Weather!
    var city: String!
    var isSeekDataBase = false
    var airQualityCoreDataModels = [AirQualityCoreDataModel]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor.whiteColor()
        setRightBarBtn()
        initTableView()
        
        if isSeekDataBase == false {
            self.title = "\(city)空气质量"
            getAirQuality(city)
        }else {
            getDataBaseSource()
            if airQualityCoreDataModels.count != 0 {
                self.title = "\(airQualityCoreDataModels[1].city)空气质量"
            }
        }
        
        
        // Do any additional setup after loading the view.
    }
    
    //MARK - 获取数据库数据
    func getDataBaseSource() {
        self.airQualityCoreDataModels = AirQualityCoreDataInstance.getData(airQuality_coredata)
    }
    
    func setRightBarBtn() {
        if isSeekDataBase == false {
            let right = UIBarButtonItem(title: "保存", style: .Done, target: self, action: "saveToDatabase")
            self.navigationItem.rightBarButtonItem = right
        }else {
            let right = UIBarButtonItem(title: "清空", style: .Done, target: self, action: "deleteDataBase")
            self.navigationItem.rightBarButtonItem = right
        }
    }
    
    func initTableView() {
        tableView = UITableView(frame: CGRectMake(0, 0, kScreenWidth, kScreenHeight), style: UITableViewStyle.Plain)
//        tableView.hidden = true
        tableView.delegate = self
        tableView.dataSource = self
        tableView.separatorStyle = .None
        tableView.rowHeight = 100
        tableView.registerClass(DetailTableViewCell.self, forCellReuseIdentifier: "detailCell")
        view.addSubview(tableView)
    }
    
    func getAirQuality(city: String) {
        let mb = MBProgressHUD.showHUDAddedTo(self.view, animated: true)
        mb.label.text = "正在加载"
        WeatherServerInstance.getAirQuality(city: "上海".changeStringToUTF8(), succeed: { (cityNow, airQualitys) -> Void in
            self.cityHistorys = airQualitys
            self.getWeather(city)
            }) { () -> Void in
                MBProgressHUD.hideHUDForView(self.view, animated: true)
                print("失败")
        }
    }
    
    func getWeather(city: String) {
        MBProgressHUD.hideHUDForView(self.view, animated: true)
        WeatherServerInstance.getWeatherForecast(city: city.changeStringToUTF8(), succeed: { (weather) -> Void in
            self.weather = weather
//            self.tableView.hidden = false
            self.tableView.reloadData()
            }) { () -> Void in
                //                MBProgressHUD.hideHUDForView(self.view, animated: true)
                print("失败")
        }
    }
    
    //MARK - 保存到数据库
    func saveToDatabase() {
        AirQualityCoreDataInstance.deleteAllData(airQuality_coredata) { () -> Void in
            debugPrint("删除数据库成功")
        }
        
        self.cityHistorys.forEach {
            let airQualityCoreDataModel = AirQualityCoreDataModel(city: self.city, date: $0.date, time: self.weather.time, temp: self.weather.temp, humidity: self.weather.humidity, quality: $0.quality, aqi: $0.AQI)
            
            AirQualityCoreDataInstance.saveData(airQuality_coredata, type: airQualityCoreDataModel)
        }
        
    }
    
    //MARK - 清空数据库
    func deleteDataBase() {
        self.airQualityCoreDataModels.removeAll()
        self.tableView.reloadData()
        AirQualityCoreDataInstance.deleteAllData(airQuality_coredata) { () -> Void in
            debugPrint("删除数据库成功")
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}

extension DetailViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        if isSeekDataBase == false {
            return self.cityHistorys.count
        }else {
            return self.airQualityCoreDataModels.count
        }
        
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("detailCell", forIndexPath: indexPath)as? DetailTableViewCell
        
        if isSeekDataBase == false {
            cell?.configure(weather, airQuality: cityHistorys[indexPath.row], isLastCell: indexPath.row == cityHistorys.count - 1)
        }else {
            cell?.configureWithDataBase(self.airQualityCoreDataModels[airQualityCoreDataModels.count - 1 - indexPath.row], isLastCell: indexPath.row == cityHistorys.count - 1)
        }
        
        return cell!
    }
}
