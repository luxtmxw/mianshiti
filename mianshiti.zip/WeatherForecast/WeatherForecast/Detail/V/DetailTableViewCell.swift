//
//  DetailTableViewCell.swift
//  WeatherForecast
//
//  Created by luxtmxw on 16/9/28.
//  Copyright © 2016年 luxtmxw. All rights reserved.
//

import UIKit

class DetailTableViewCell: UITableViewCell {
    var dateLbl: UILabel!
    var timeLbl: UILabel!
    var tempLbl: UILabel!
    var humidityLbl: UILabel!
    var AQILbl: UILabel!
    var qualityLbl: UILabel!
    var grayLine: UIView!
    
    override init(style: UITableViewCellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        self.initFrame()
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func initFrame() {
        self.selectionStyle = .None
        
        dateLbl = UILabel(frame: CGRectMake(27,19,100,21))
        dateLbl.detailInitLbl()
        contentView.addSubview(dateLbl)
        
        timeLbl = UILabel(frame: CGRectMake(dateLbl.endX + 18, 19, 50, 21))
        timeLbl.detailInitLbl()
        contentView.addSubview(timeLbl)
        
        tempLbl = UILabel(frame: CGRectMake(kScreenWidth - 92, 5, 92, 21))
        tempLbl.detailInitLbl()
        contentView.addSubview(tempLbl)
        
        humidityLbl = UILabel(frame: CGRectMake(kScreenWidth - 92, tempLbl.endY + 3, 92, 21))
        humidityLbl.detailInitLbl()
        contentView.addSubview(humidityLbl)
        
        AQILbl = UILabel(frame: CGRectMake(kScreenWidth - 92, humidityLbl.endY + 3, 92, 21))
        AQILbl.detailInitLbl()
        contentView.addSubview(AQILbl)
        
        qualityLbl = UILabel(frame: CGRectMake(kScreenWidth - 92, AQILbl.endY + 3, 92, 21))
        qualityLbl.detailInitLbl()
        contentView.addSubview(qualityLbl)
        
        grayLine = UIView(frame: CGRectMake(14.5, 99, kScreenWidth - 29, 1))
        grayLine.backgroundColor = UIColor.colorWithHexCode("eee")
        contentView.addSubview(grayLine)
    }
    
    func configure(weather: Weather, airQuality: AirQuality, isLastCell: Bool) {
        self.dateLbl.text = airQuality.date
        self.timeLbl.text = weather.time
        self.tempLbl.text = "温度:  \(weather.temp)"
        self.humidityLbl.text = "湿度:  \(weather.humidity)"
        self.AQILbl.text = "AQI:  \(airQuality.AQI)"
        self.qualityLbl.text = "空气质量: \(airQuality.quality)"
        
        if isLastCell {
            self.grayLine.hidden = true
        }
    }
    
    func configureWithDataBase(airQuality: AirQualityCoreDataModel, isLastCell: Bool) {
        self.dateLbl.text = airQuality.date
        self.timeLbl.text = airQuality.time
        self.tempLbl.text = "温度:  \(airQuality.temp)"
        self.humidityLbl.text = "湿度:  \(airQuality.humidity)"
        self.AQILbl.text = "AQI:  \(airQuality.aqi)"
        self.qualityLbl.text = "空气质量: \(airQuality.quality)"
        
        if isLastCell {
            self.grayLine.hidden = true
        }
        
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}

extension UILabel {
    func detailInitLbl() {
        self.font = UIFont.systemFontOfSize(15)
        self.textColor = UIColor.colorWithHexCode("666")
    }
}
