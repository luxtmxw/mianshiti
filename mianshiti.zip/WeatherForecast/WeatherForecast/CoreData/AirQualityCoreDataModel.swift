//
//  AirQualityCoreDataModel.swift
//  WeatherForecast
//
//  Created by luxtmxw on 16/9/28.
//  Copyright © 2016年 luxtmxw. All rights reserved.
//

import UIKit

class AirQualityCoreDataModel: NSObject {
    var city: String!
    var date: String!
    var time: String!
    var temp: String!
    var humidity: String!
    var quality: String!
    var aqi: String!
    
    
    convenience init(city: String, date: String, time: String, temp: String, humidity: String, quality: String, aqi: String) {
        self.init()
        self.city = city
        self.date = date
        self.time = time
        self.temp = temp
        self.humidity = humidity
        self.quality = quality
        self.aqi = aqi
    }
}
