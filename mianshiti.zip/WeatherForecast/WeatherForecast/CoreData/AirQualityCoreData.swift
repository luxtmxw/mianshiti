//
//  AirQualityCoreData.swift
//  WeatherForecast
//
//  Created by luxtmxw on 16/9/28.
//  Copyright © 2016年 luxtmxw. All rights reserved.
//

import UIKit
import CoreData

let AirQualityCoreDataInstance = AirQualityCoreData.sharedInstance
class AirQualityCoreData: NSObject {
    
    static let sharedInstance = AirQualityCoreData()
    var datas = [NSManagedObject]()
    
    //MARK: - 保存数据
    func saveData(entity: String, type: AirQualityCoreDataModel) {
        //1
        let appDelegate =
        UIApplication.sharedApplication().delegate as! AppDelegate
        let managedContext = appDelegate.managedObjectContext!
        //2
        let entit =  NSEntityDescription.entityForName(entity,
            inManagedObjectContext:
            managedContext)
        let attributes = NSManagedObject(entity: entit!,
            insertIntoManagedObjectContext:managedContext)
        //3
        attributes.setValue(type.city, forKey: "city")
        attributes.setValue(type.date, forKey: "date")
        attributes.setValue(type.time, forKey: "time")
        attributes.setValue(type.temp, forKey: "temp")
        attributes.setValue(type.humidity, forKey: "humidity")
        attributes.setValue(type.aqi, forKey: "aqi")
        attributes.setValue(type.quality, forKey: "quality")
        //4
        do {
            try managedContext.save()
            print("save succeed")
        }
        catch {
            print("Could not save")
        }
    }
    
    //MARK: - 获取数据
    func getData(entity: String) -> [AirQualityCoreDataModel] {
        var airQualitys = [AirQualityCoreDataModel]()
        //1
        let appDelegate =
        UIApplication.sharedApplication().delegate as! AppDelegate
        let managedContext = appDelegate.managedObjectContext!
        //2
        let fetchRequest = NSFetchRequest(entityName: entity)
        //3
        do {
            try datas = managedContext.executeFetchRequest(fetchRequest) as! [NSManagedObject]
            for i in 0..<datas.count {
                let data = datas[i]
                let airQuality = AirQualityCoreDataModel(city:data.valueForKey("city") as! String,
                    date: data.valueForKey("date") as! String,
                    time: data.valueForKey("time") as! String,
                    temp: data.valueForKey("temp") as! String,
                    humidity: data.valueForKey("humidity") as! String,
                    quality: data.valueForKey("quality") as! String,
                    aqi: data.valueForKey("aqi") as! String)
                airQualitys.insert(airQuality, atIndex: 0)
            }
        }
        catch {
            print("Could not fetch")
        }
        return airQualitys
    }
    
    //MARK: - 查询数据
    func searchData(entity: String, key : String) -> AirQualityCoreDataModel? {
        var result: NSManagedObject!
        result = CoreDataManager.sharedInstance.searchData(entity, key: key)
        if result == nil {
            return nil
        }
        let airQuality: AirQualityCoreDataModel!
        airQuality = AirQualityCoreDataModel(city: result.valueForKey("city") as! String,
            date: result.valueForKey("date") as! String,
            time: result.valueForKey("time") as! String,
            temp: result.valueForKey("temp") as! String,
            humidity: result.valueForKey("humidity") as! String,
            quality: result.valueForKey("quality") as! String,
            aqi: result.valueForKey("aqi") as! String)
        return airQuality
    }
    
    //MARK: - 删除数据
    func deleteData(entity: String, key: String) {
        CoreDataManager.sharedInstance.deleteData(entity, key: key) { (deleted) -> Void in
            if deleted == true {
                print("删除成功")
            }else {
                print("删除失败")
            }
        }
    }
    
    //MARK: - 删除所有数据
    func deleteAllData(entity: String, succeed: () -> Void) {
        CoreDataManager.sharedInstance.deleteAllData(entity) { () -> Void in
            succeed()
        }
    }
}
