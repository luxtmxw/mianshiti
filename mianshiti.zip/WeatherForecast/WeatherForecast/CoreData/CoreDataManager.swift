//
//  CoreDataManager.swift
//  CteemoCN
//
//  Created by MrMessy on 15/12/16.
//  Copyright © 2015年 bintao. All rights reserved.
//

import UIKit
import CoreData

class CoreDataManager: NSObject {
    static let sharedInstance = CoreDataManager()
    var datas = [NSManagedObject]()

    //MARK: - 查询数据
    func searchData(entity: String, key : String) -> NSManagedObject? {
        var result: [NSManagedObject]!
        //1
        let appDelegate =
        UIApplication.sharedApplication().delegate as! AppDelegate
        let managedContext = appDelegate.managedObjectContext!
        //2
        let fetchRequest = NSFetchRequest()
        //3
        //声明一个实体结构
        let entity:NSEntityDescription? = NSEntityDescription.entityForName(entity,
            inManagedObjectContext: managedContext)
        //设置数据请求的实体结构
        fetchRequest.entity = entity
        //查询操作
        do {
            try datas = managedContext.executeFetchRequest(fetchRequest) as! [NSManagedObject]
            result = datas.filter({ (object) -> Bool in
                if object.valueForKey("id") as! String == key {
                    return true
                }
                return false
            })
        }catch {
            print("未找到相关数据")
        }
        if result.count == 0 {
            return nil
        }
        return result[0]
    }
    
    //MARK: - 删除数据
    func deleteData(entity: String, key: String, succeed: (deleted: Bool) -> Void) {
        let appDelegate =
        UIApplication.sharedApplication().delegate as! AppDelegate
        let managedContext = appDelegate.managedObjectContext!
        let data = self.searchData(entity, key: key)
        if data != nil {
            managedContext.deleteObject(data!)
        }else {
            return
        }
        do {
            try managedContext.save()
            succeed(deleted: true)
            print("save succeed")
        }
        catch {
            succeed(deleted: false)
            print("Could not save")
        }
    }
    
    //MARK: - 删除所有数据
    func deleteAllData(entity: String, succeed: () -> Void) {
        let appDelegate =
        UIApplication.sharedApplication().delegate as! AppDelegate
        let managedContext = appDelegate.managedObjectContext!
        //2
        let fetchRequest = NSFetchRequest(entityName: entity)
        //3
        do {
            try datas = managedContext.executeFetchRequest(fetchRequest) as! [NSManagedObject]
            for data in datas {
                managedContext.deleteObject(data)
            }
        }
        catch {
            print("Could not fetch")
        }
        do {
            try managedContext.save()
            succeed()
            print("save succeed")
        }
        catch {
            print("Could not save")
        }
    }
    
    //MARK: - 修改数据
    func modifyData(entity: String, id: String, value: AnyObject, key: String, succeed: (Bool) -> Void) {
        let appDelegate =
        UIApplication.sharedApplication().delegate as! AppDelegate
        let managedContext = appDelegate.managedObjectContext!
        let data = searchData(entity, key: id)
        data!.setValue(value, forKey: key)
        do {
            try managedContext.save()
            succeed(true)
            print("save succeed")
        }
        catch {
            succeed(false)
            print("Could not save")
        }
    }
}
