//
//  SystemSettingViewController.swift
//  WeatherForecast
//
//  Created by luxtmxw on 16/9/28.
//  Copyright © 2016年 luxtmxw. All rights reserved.
//

import UIKit

class SystemSettingViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "系统设置"
        self.navigationItem.backBarButtonItem = UIBarButtonItem(title: " ", style: .Done, target: nil, action: nil)

        // Do any additional setup after loading the view.
    }

    @IBAction func SeekDataBase(sender: AnyObject) {
        let detailVC = DetailViewController()
        detailVC.isSeekDataBase = true
        navigationController?.pushViewController(detailVC, animated: true)
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
