//
//  ViewController.swift
//  WeatherCastDemo
//
//  Created by luxtmxw on 16/9/26.
//  Copyright © 2016年 luxtmxw. All rights reserved.
//

import UIKit

enum Repayment {
    case benxi,
    benjin
}

class ViewController: UIViewController {
    @IBOutlet weak var preTaxSalary: UITextField!
    @IBOutlet weak var loanAmount: UITextField!
    @IBOutlet weak var loanLimit: UITextField!
    @IBOutlet weak var interest: UITextField!
    @IBOutlet weak var showRepaymentWay: UILabel!
    @IBOutlet weak var repaymentWay: UISwitch!
    var repayment = Repayment.benxi
    var number = [[2,8,8]]
    var numberAfter = [[2,8,8]]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    @IBAction func countTax(sender: AnyObject) {
        view.endEditing(true)
        preTaxSalary.text?.countTax()
    }
    
    @IBAction func countLoan(sender: AnyObject) {
        view.endEditing(true)
        if repayment == .benxi {
            benxiArithmetic()
        }else {
            benjinArithmetic()
        }
        
    }
    
    //MARK: - 还款方式
    @IBAction func repayWay(sender: AnyObject) {
        view.endEditing(true)
        if repaymentWay.on {
            showRepaymentWay.text = "等额本息还款"
            repayment = .benxi
        }else {
            showRepaymentWay.text = "等额本金还款"
            repayment = .benjin
        }
    }
    
    //MARK: - 本息还款算法
    func benxiArithmetic() {
        let loanAmount = Double(self.loanAmount.text!)
        let loanLimit = Double(self.loanLimit.text!)
        let monthAmount = loanLimit! * 12
        let interest_month = Double(self.interest.text!)! / 100 / monthAmount
        let monthPayBase = loanAmount! / monthAmount
        var monthPayCount = 0.0
        for i in 0..<Int(monthAmount) {
           let monthPay = monthPayBase + (loanAmount! - monthPayBase * Double(i)) * interest_month
            print("第\(i+1)月需支付:\(monthPay)元")
            monthPayCount += monthPay
        }
        
        print("总共需要还:\(monthPayCount)元")
        print("总利息为:\(monthPayCount - loanAmount!)元")
        
    }
    
    //MARK: - 本金还款算法
    func benjinArithmetic() {
        let loanAmount = Double(self.loanAmount.text!)
        let loanLimit = Double(self.loanLimit.text!)
        let monthAmount = loanLimit! * 12
        let interest_month = Double(self.interest.text!)! / 100 / monthAmount
        let rePayAmount = loanAmount! * pow((1 + interest_month), monthAmount)
        print("总还款:\(rePayAmount)")
        print("总利息:\(rePayAmount - loanAmount!)")
        
    }
    
    @IBAction func count24(sender: AnyObject) {
        number.removeAll()
        for i in 1..<10 {
            for j in i+1..<10 {
                for k in j+1..<10 {
                    if i*j+k == 24 || i*k+j == 24 ||  j*k+i == 24 || i*j-k == 24 || i*k-j == 24 ||  j*k-i == 24 || i*j/k == 24 || i*k/j == 24 ||  j*k/i == 24 || i+j-k == 24 || i+k-j == 24 ||  j+k-i == 24 || i+j+k==24 || i*j*k == 24 {
                        number.append([i,j,k])
                    }
                }
            }
        }
        
        number.forEach{
            print($0)
        }
        
    }

    override func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {
        view.endEditing(true)
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

extension String {
    func countTax() {
        let preTax = Double(self)
        print("税前工资为:\(preTax!)")
        let socialBase = preTax >= 3563 ? preTax : 3563
        let fundBase = preTax >= 2020 ? preTax : 2020
        let socialAndFund = socialBase! * 0.105 + fundBase! * 0.07
        print("五险一金为:\(socialAndFund)")
        
        let personalTaxBase = preTax! - socialAndFund - 3500
        var personalTax = 0.0
        if personalTaxBase > 0 {
            if personalTaxBase < 1500 {
                personalTax = (preTax! - socialAndFund) * 0.03
            }else if personalTaxBase >= 1500 && personalTaxBase < 4500 {
                personalTax = personalTaxBase * 0.1 - 105
            }else if personalTaxBase >= 4500 && personalTaxBase < 9000 {
                personalTax = personalTaxBase * 0.2 - 555
            }else if personalTaxBase >= 9000 && personalTaxBase < 35000 {
                personalTax = personalTaxBase * 0.25 - 1005
            }else if personalTaxBase >= 35000 && personalTaxBase < 55000 {
                personalTax = personalTaxBase * 0.3 - 2755
            }else if personalTaxBase >= 55000 && personalTaxBase < 80000 {
                personalTax = personalTaxBase * 0.35 - 5505
            }else {
                personalTax = personalTaxBase * 0.45 - 13505
            }
        }else {
            personalTax = 0
        }
        print("个人所得税为:\(personalTax)")
        print("税后工资为:\(preTax! - socialAndFund - personalTax)")
    }
}

